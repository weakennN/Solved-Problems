package Generics;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        List<String> list = new ArrayList<>();
        int n = Integer.parseInt(scan.nextLine());

        for (int i = 0; i < n; i++) {
            String input = scan.nextLine();
            list.add(input);
        }

        String[] indexToSwap = scan.nextLine().split("\\s+");
        int index1 = Integer.parseInt(indexToSwap[0]);
        int index2 = Integer.parseInt(indexToSwap[1]);


        String a = list.get(0);
        list.set(index1, list.get(index2));
        list.set(index2, a);

        for (int i = 0;i < list.size();i++){

            String clazz = list.get(i).getClass() + "";
            String classToString = clazz.substring(clazz.indexOf('j'));
            System.out.printf("%s: %s%n",classToString, list.get(i));
        }
    }
}
